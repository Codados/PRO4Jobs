/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author Wunderlich
 */
public class CandidataVaga {
    private String id_vaga;
    private String status_vaga;

    /**
     * @return the status_vaga
     */
    public String getStatus_vaga() {
        return status_vaga;
    }

    /**
     * @param status_vaga the status_vaga to set
     */
    public void setStatus_vaga(String status_vaga) {
        this.status_vaga = status_vaga;
    }

    /**
     * @return the id_vaga
     */
    public String getId_vaga() {
        return id_vaga;
    }

    /**
     * @param id_vaga the id_vaga to set
     */
    public void setId_vaga(String id_vaga) {
        this.id_vaga = id_vaga;
    }
}
