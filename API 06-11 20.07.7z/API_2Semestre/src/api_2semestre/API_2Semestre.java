/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package api_2semestre;

import View.Home;




/**
 *
 * @author Lucas Emanoel
 */
public class API_2Semestre {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Home().setVisible(true);
    }
    
}
